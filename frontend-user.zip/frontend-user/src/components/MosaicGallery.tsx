import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Calendar, Star, ExternalLink, Music } from 'lucide-react'
import { apiService, Band } from '../services/api'

interface MosaicGalleryProps {
  bandas?: Band[]
}

// Componente para um card individual da banda
const BandCard: React.FC<{ banda: Band; index: number }> = ({ banda, index }) => {
  // Função para determinar o tamanho do card baseado no índice (efeito mosaico)
  const getCardSize = (index: number) => {
    const patterns = [
      'sm:col-span-2 sm:row-span-2 lg:col-span-2 lg:row-span-2', // Card grande (2x2)
      'sm:col-span-1 sm:row-span-1 lg:col-span-1 lg:row-span-1', // Card normal (1x1)
      'sm:col-span-1 sm:row-span-1 lg:col-span-1 lg:row-span-1', // Card normal (1x1)
      'sm:col-span-1 sm:row-span-2 lg:col-span-1 lg:row-span-2', // Card alto (1x2)
      'sm:col-span-2 sm:row-span-1 lg:col-span-2 lg:row-span-1', // Card largo (2x1)
      'sm:col-span-1 sm:row-span-1 lg:col-span-1 lg:row-span-1', // Card normal (1x1)
    ]
    return patterns[index % patterns.length]
  }

  // Determinar se é um card grande para mostrar mais informações
  const isLargeCard = getCardSize(index).includes('col-span-2') || getCardSize(index).includes('row-span-2')

  return (
    <motion.div
      className={`group relative ${getCardSize(index)}`}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      viewport={{ once: true }}
    >
      <div className="bg-gray-800 shadow-lg rounded-xl overflow-hidden h-full hover:shadow-2xl transition-all duration-300 hover:scale-[1.02]">
        {/* Badge de destaque */}
        {banda.featured && (
          <motion.div
            className="absolute top-3 left-3 z-20"
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            transition={{ duration: 0.3, delay: 0.5 }}
            viewport={{ once: true }}
          >
            <span className="text-xs font-bold px-2 sm:px-3 py-1 sm:py-1.5 rounded-full bg-orange-500 text-white shadow-lg">
              ⭐ Em Destaque
            </span>
          </motion.div>
        )}

        {/* Container principal com proporção equilibrada */}
        <div className="flex flex-col h-full">
          {/* Seção da imagem - 60% da altura com container responsivo */}
          <div className="relative h-3/5 overflow-hidden bg-gray-700">
            {/* Container da imagem com proporção responsiva */}
            <div className="w-full h-full flex items-center justify-center p-2">
              <motion.img
                src={banda.image_url || '/api/placeholder/400/300'}
                alt={`Imagem da banda ${banda.name}`}
                className="w-auto h-auto max-w-full max-h-full object-contain transition-transform duration-500 group-hover:scale-105"
                style={{
                  objectFit: 'contain'
                }}
                onError={(e) => {
                  e.currentTarget.src = '/api/placeholder/400/300'
                }}
              />
            </div>
            
            {/* Overlay sutil sempre visível para melhor contraste */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent pointer-events-none" />
            
            {/* Botão de link sempre visível para acessibilidade */}
            {banda.official_url && (
              <div className="absolute top-2 right-2 z-10">
                <motion.a
                  href={banda.official_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-black/70 hover:bg-orange-600 text-white p-1.5 sm:p-2 rounded-full transition-colors duration-200 shadow-lg"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  aria-label={`Visitar site oficial de ${banda.name}`}
                >
                  <ExternalLink className="w-3 h-3 sm:w-4 sm:h-4" />
                </motion.a>
              </div>
            )}
          </div>

          {/* Seção de informações - 40% da altura */}
          <div className="flex-1 p-3 sm:p-4 bg-gray-800">
            {/* Nome da banda */}
            <h3 className="font-bold text-white mb-2 line-clamp-2 text-sm sm:text-base leading-tight">
              {banda.name}
            </h3>
            
            {/* Descrição - apenas em cards grandes para evitar sobrecarga */}
            {isLargeCard && banda.description && (
              <p className="text-xs sm:text-sm text-gray-300 mb-2 sm:mb-3 line-clamp-2 leading-relaxed">
                {banda.description}
              </p>
            )}
            
            {/* Meta informações sempre visíveis */}
            <div className="space-y-1.5 sm:space-y-2">
              {/* Gênero */}
              {banda.genre_tags && (
                <div className="flex items-center gap-1.5 sm:gap-2 text-xs text-gray-300">
                  <Calendar className="w-3 h-3 text-orange-400 flex-shrink-0" />
                  <span className="line-clamp-1 text-xs">
                    {banda.genre_tags.length > 20 
                      ? `${banda.genre_tags.substring(0, 20)}...` 
                      : banda.genre_tags
                    }
                  </span>
                </div>
              )}
              
              {/* Status de destaque */}
              {banda.featured && (
                <div className="flex items-center gap-1.5 sm:gap-2 text-xs text-orange-400">
                  <Star className="w-3 h-3 fill-current flex-shrink-0" />
                  <span className="font-medium text-xs">Em Destaque</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

const MosaicGallery: React.FC<MosaicGalleryProps> = ({ 
  bandas: propBandas 
}) => {
  const [bandas, setBandas] = useState<Band[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadBandas = async () => {
      try {
        setLoading(true)
        // Se não foram passados via props, buscar da API
        if (!propBandas || propBandas.length === 0) {
          const apiBandas = await apiService.getDestaquesPublicos()
          setBandas(apiBandas)
        } else {
          setBandas(propBandas)
        }
      } catch (error) {
        console.error('Erro ao carregar bandas da cena:', error)
        setBandas([])
      } finally {
        setLoading(false)
      }
    }

    loadBandas()
  }, [propBandas])

  // Estado de loading
  if (loading) {
    return (
      <section id="destaques" className="py-20 bg-gradient-to-b from-gray-900 to-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-wider">
               BANDAS DA CENA
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              As bandas mais pesadas do momento
            </p>
          </div>
          
          <div className="flex justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
          </div>
        </div>
      </section>
    )
  }

  // Estado vazio
  if (bandas.length === 0) {
    return (
      <section id="destaques" className="py-20 bg-gradient-to-b from-gray-900 to-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-wider">
              🎸 BANDAS DA CENA
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              As bandas mais pesadas do momento
            </p>
          </div>
          
          <div className="text-center">
            <Music className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-300">Nenhuma banda em destaque no momento</p>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section id="destaques" className="py-20 bg-gradient-to-b from-gray-900 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Título da seção */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4 tracking-wider">
            🎸 BANDAS DA CENA
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            As bandas mais pesadas do momento
          </p>
        </div>

        {/* Grid em mosaico responsivo */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6 auto-rows-[280px] sm:auto-rows-[300px] lg:auto-rows-[320px]">
          {bandas.map((banda, index) => (
            <BandCard 
              key={banda.id} 
              banda={banda} 
              index={index} 
            />
          ))}
        </div>
      </div>
    </section>
  )
}

export default MosaicGallery

