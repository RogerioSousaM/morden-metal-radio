/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'metal-dark': '#000000',
        'metal-black': '#0b0b0b',
        'metal-card': '#121212',
        'metal-gray': '#1a1a1a',
        'metal-light-gray': '#2a2a2a',
        'metal-text': '#ffffff',
        'metal-text-secondary': '#a0a0a0',
        'metal-orange': '#E04E1B',
        'metal-accent': '#FF5722',
        'metal-red': '#f44336',
      },
      fontFamily: {
        'metal': ['Orbitron', 'Courier New', 'monospace'],
        'display': ['Orbitron', 'Courier New', 'monospace'],
        'body': ['Inter', 'system-ui', 'sans-serif'],
        'sans': ['Inter', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'xs': ['0.75rem', { lineHeight: '1.25' }],
        'sm': ['0.875rem', { lineHeight: '1.5' }],
        'base': ['1rem', { lineHeight: '1.5' }],
        'lg': ['1.125rem', { lineHeight: '1.75' }],
        'xl': ['1.25rem', { lineHeight: '1.25' }],
        '2xl': ['1.5rem', { lineHeight: '1.25' }],
        '3xl': ['1.875rem', { lineHeight: '1.25' }],
        '4xl': ['2.25rem', { lineHeight: '1.25' }],
        '5xl': ['3rem', { lineHeight: '1.25' }],
        '6xl': ['3.75rem', { lineHeight: '1' }],
        '7xl': ['4.5rem', { lineHeight: '1' }],
      },
      letterSpacing: {
        'tight': '-0.025em',
        'wide': '0.025em',
        'wider': '0.05em',
        'widest': '0.1em',
      },
      animation: {
        'glow-pulse': 'glow-pulse 2s ease-in-out infinite alternate',
        'micro-pulse': 'micro-pulse 2s ease-in-out infinite',
      },
      keyframes: {
        'glow-pulse': {
          '0%': {
            boxShadow: '0 0 5px #f44336, 0 0 10px #f44336, 0 0 15px #f44336',
          },
          '100%': {
            boxShadow: '0 0 10px #f44336, 0 0 20px #f44336, 0 0 30px #f44336',
          },
        },
        'micro-pulse': {
          '0%, 100%': {
            transform: 'scale(1)',
            opacity: '1',
          },
          '50%': {
            transform: 'scale(1.05)',
            opacity: '0.8',
          },
        },
      },
    },
  },
  plugins: [],
} 